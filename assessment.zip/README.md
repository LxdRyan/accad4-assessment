# ACCAD4 Assessment Static Website

This is a static website that is to be deployed using AWS CodePipeline.

Submitted by Ryan